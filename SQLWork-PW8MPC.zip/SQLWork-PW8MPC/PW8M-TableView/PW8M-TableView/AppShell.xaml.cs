﻿namespace PW8M_TableView;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
