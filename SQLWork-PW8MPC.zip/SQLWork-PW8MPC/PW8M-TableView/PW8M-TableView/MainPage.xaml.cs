﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Configuration.Provider;

namespace PW8M_TableView;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
        connection = new SqlConnection(connectionString);
    }
	public static List<Movement> Movements;//Заменять IP
    string connectionString = "data source=localhost\\SQLExpress;initial catalog=Завод;user id=sa;password=1234;Integrated Security=False;Trusted_Connection=False;";
    //Настройки безопасности и надежности надо менять для remote connect на false
    SqlConnection connection;
    private void ConnectToBase_Clicked(object sender, EventArgs e)
	{
		try
		{
            Movements = new List<Movement>();
            connection.Open();//Обязательно открывать перед любыми действиями
            DisplayAlert("Загрузка БД", "БД ЗАГРУЖЕНА", "ДА!!!!");
			SqlCommand command = new SqlCommand("Select * From Movement", connection);
			SqlDataReader reader = command.ExecuteReader();
			while (reader.Read())
			{
				Movements.Add(new Movement
				{
					DetailID = Convert.ToInt32(reader["DetailID"]),
					DetailName = reader["DetailName"].ToString(),
                    DetailCount = Convert.ToInt32(reader["DetailCount"])
                });
			}
			reader.Close();
			connection.Close();
			ID.Text = Movements[0].DetailID.ToString();
			Name.Text = Movements[0].DetailName;
			Count.Text = Movements[0].DetailCount.ToString();
			//list.Where(p => p.DetailID == 1); - LINQ moment
			//int count = (from p in list where p.DetailID == 1 select p).Count(); - LINQ moment 2
        }
		catch(Exception ex)
		{
            connection.Close();//Обязательно при краше
            DisplayAlert("Нет БД", "СКРИПТ ЗАЮЗАЙ!", "OK");//Ну типо так понятнее            
        }
	}
	private async void AddToBase_Clicked(object sender, EventArgs e)
	{
		try
		{
			if (Movements == null)
			{
                await DisplayAlert("Загрузка БД", "Перед началом действий необходимо загрузить БД", "OK");//Ну типо так понятнее
				return;
            }
			connection.Open();
			SqlCommand command = new SqlCommand("Insert INTO Movement (DetailID, DetailName, DetailCount) Values(@ID, @Name, @Count)", connection);
			command.Parameters.Add(new SqlParameter("ID", Convert.ToInt32(ID.Text)));
			command.Parameters.Add(new SqlParameter("Name", Name.Text));
			command.Parameters.Add(new SqlParameter("Count", Convert.ToInt32(Count.Text)));
			command.ExecuteNonQuery();			
			connection.Close();
			await DisplayAlert("Выполено добавление", "Проверьте таблицу", "OK");//Ну типо так понятнее
		}
		catch
		{
            connection.Close();//Обязательно при краше
            await DisplayAlert("Ошибка", "Чутка лоханулся", "OK");//Ну типо так понятнее            
        }
    }

	private async void DeleteOnProc_Clicked(object sender, EventArgs e)//Удаление(Процедура действий) через встроенную процедуру
	{
		try
		{
            if (Movements == null)
            {
                await DisplayAlert("Загрузка БД", "Перед началом действий необходимо загрузить БД", "OK");//Ну типо так понятнее
                return;
            }
            connection.Open();
			SqlCommand command = new SqlCommand("RemoveDetail", connection);
			command.CommandType = System.Data.CommandType.StoredProcedure;
			command.Parameters.Add(new SqlParameter("DetailID", Convert.ToInt32(Convert.ToInt32(ID.Text))));
			command.ExecuteNonQuery();
			connection.Close();
            await DisplayAlert("Выполено удаление", "Проверьте таблицу", "OK");//Ну типо так понятнее
        }
        catch
        {
            connection.Close();//Обязательно при краше
            await DisplayAlert("Ошибка", "Чутка лоханулся", "OK");//Ну типо так понятнее            
        }
    }
    private async void GetDetailCount_Clicked(object sender, EventArgs e)//Получение(Результативная процедура) значения из процедуры
    {
        try
        {
            if (Movements == null)
            {
                await DisplayAlert("Загрузка БД", "Перед началом действий необходимо загрузить БД", "OK");//Ну типо так понятнее
                return;
            }
            connection.Open();
            SqlCommand command = new SqlCommand("GetDetailCost", connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
				ID.Text = reader["Cost"].ToString();               
            }
            reader.Close();
            connection.Close();
            await DisplayAlert("Стоимость найдена", "Проверьте поле кода", "OK");//Ну типо так понятнее
        }
        catch
        {
			connection.Close();//Обязательно при краше
            await DisplayAlert("Ошибка", "Чутка лоханулся", "OK");//Ну типо так понятнее            
        }
    }
}

