namespace PW8M_TableView;

public partial class DBPage : ContentPage
{
	public DBPage()
	{
		InitializeComponent();
    }

	private void UpdateView_Clicked(object sender, EventArgs e)
	{
		MovementView.ItemsSource = null;
		MovementView.ItemsSource = MainPage.Movements;
	}
}