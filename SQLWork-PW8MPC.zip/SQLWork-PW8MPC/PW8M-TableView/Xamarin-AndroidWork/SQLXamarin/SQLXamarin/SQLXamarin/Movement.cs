﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLXamarin
{
    public class Movement//Горячая пропись для последующего использования
    {
        public int DetailID { get; set; }
        public string DetailName { get; set; }
        public int DetailCount { get; set; }
    }
}
